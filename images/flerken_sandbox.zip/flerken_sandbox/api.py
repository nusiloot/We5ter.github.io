#!/usr/bin/python
# -*-coding:utf-8-*-

"""
Flask REST API
"""

__author__ = 'Zhiyang Zeng'
__copyright__ = "Copyright 2019, Apache License 2.0"

from flask import Flask
from flask_restful import Resource, Api, reqparse
from analyze import Analyze

app = Flask(__name__)
api = Api(app)

parser = reqparse.RequestParser()
parser.add_argument('cmd', type=str)


class Sandbox(Resource):
    def get(self):
        return {'version': 'v1'}

    def post(self):
        args = parser.parse_args()
        #print(args['cmd'])
        ana = Analyze(args['cmd'])
        ana.analyze()
        return ana.res

api.add_resource(Sandbox, '/v1/sandbox')