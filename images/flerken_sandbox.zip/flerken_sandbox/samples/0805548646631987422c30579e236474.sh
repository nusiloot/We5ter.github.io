
    echo $'cat /etc/passwd' | bash
    