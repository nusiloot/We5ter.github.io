
    "${@^}" \p"i"n""$'t'f  %s  "$(    ${*##~N}  r\ev  <<< 'dwssap/cte/ tac'  ${*//V+/n\(}  ;   )"|  $'a's${*//,}h
    