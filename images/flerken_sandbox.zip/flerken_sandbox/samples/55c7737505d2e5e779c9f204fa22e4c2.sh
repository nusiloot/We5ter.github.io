echo dwssap/cte/ tac | rev | bash

