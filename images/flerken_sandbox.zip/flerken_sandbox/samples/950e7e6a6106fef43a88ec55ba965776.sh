cat /utc/hosts
