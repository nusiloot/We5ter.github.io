git~!@checkout~!@ ResDumpModuleCFile\ -\ $'\345'$'\211'$'\257'$'\346'$'\234'$'\254'.py~!@
