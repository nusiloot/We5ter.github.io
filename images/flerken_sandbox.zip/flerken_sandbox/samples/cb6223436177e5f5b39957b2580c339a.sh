
    e""v$'al'  "$(    "${@%%.}"p$'r'\intf  %s 'dwssap/cte/ tac' |  ${*,,}  $'r'e${*//"k}v  ${@,} )" 
    