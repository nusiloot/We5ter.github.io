# -*- coding:utf-8 -*-

import json
import re


class simhash:
    def __init__(self, tokens=[], hashbits=128):
        self.hashbits = hashbits
        self.hash = self.simhash(tokens)

    def __str__(self):
        return str(self.hash)

    def simhash(self, tokens):
        v = [0] * self.hashbits
        for t in [self._string_hash(x) for x in tokens]:
            for i in range(self.hashbits):
                bitmask = 1 << i
                if t & bitmask:
                    v[i] += 1
                else:
                    v[i] -= 1
        fingerprint = 0
        for i in range(self.hashbits):
            if v[i] >= 0:
                fingerprint += 1 << i
        return fingerprint

    @staticmethod
    def haiming_distance(hash_a, hash_b, hashbits=128):
        x = (hash_a ^ hash_b) & ((1 << hashbits) - 1)
        tot = 0;
        while x:
            tot += 1
            x &= x - 1
        return tot

    def similarity(hash_a, hash_b):
        a = float(hash_a)
        b = float(hash_b)
        if a > b:
            return b / a
        else:
            return a / b

    def _string_hash(self, source):
        if source == "":
            return 0
        else:
            x = ord(source[0]) << 7
            m = 1000003
            mask = 2 ** self.hashbits - 1
            for c in source:
                x = ((x * m) ^ ord(c)) & mask
            x ^= len(source)
            if x == -1:
                x = -2
            return x


if __name__ == '__main__':
    str1 = "c:\winddk\\760015~1.1\\bin\\x86\\x86\cl.exe @d:\jenkin~1\worksp~1\pcmgr1~2\qqpcmg~1\sxproj~1\source\qmemdrv\objchk_w"
    str2 = "c:\winfdk\\760016~1.1\\bin\\x86\\x86\cl.exe @d:\jenkin~1\worksp~1\pcmgr1~2\qqpcmg~1\sxproj~1\source\qmem"

    # str2 = str2[0:100]
    # str1 = str1[0:100]
    str1h = simhash(str1).hash
    str2h = simhash(str2).hash

    haiming_dis = simhash.haiming_distance(str1h, str2h)
    print(str(haiming_dis))
