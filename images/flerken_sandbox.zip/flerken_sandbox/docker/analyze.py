#!/usr/bin/python
# -*-coding:utf-8-*-

"""
Analyze
"""

import subprocess
import re
import hashlib
from simhash import simhash

class Analyze():

    def __init__(self, cmd):
        self.cmd = cmd
        self.res = {}

    def _name_hash(self):
        m = hashlib.md5(self.cmd.encode("utf-8"))
        return m.hexdigest()

    def _init_file(self):
        file_name = self._name_hash()+'.sh'
        with open('./samples/'+file_name, 'w') as f:
            f.write(self.cmd+'\n')
        return file_name

    def _func_hit(self, array):
        res_list = []
        func_list = ['rev', 'md5', 'ar', 'bunzip', 'bzip', 'gunzip', 'zip', 'tar', 'compress', 'cpio', 'dump', 'lha', 'unarj', 'gzexe', 'gzip', 'uudecode', 'base64', 'restore']
        for ar in array:
            cmd_nospace = (ar['cmd']).strip()
            for func in func_list:
                if cmd_nospace.startswith(func):
                    if cmd_nospace not in res_list:
                        res_list.append(cmd_nospace)
                    else:
                        continue
        return res_list

    def _bash_debug(self):
        output = subprocess.getstatusoutput('./octopusbash -x ./samples/'+self._init_file())
        #print(output)
        r = re.compile(r'.*\.sh\:\s+line\s+\d+\:')
        if r.search(output[1]):
            cmd_dict = []
            return cmd_dict
        elif output[0] != 0:
            cmd_dict = []
            return cmd_dict

        res_array = output[1].split('\n')
        cmd_dict = [None] * len(res_array)

        for index in range(len(res_array)):
            if res_array[index].startswith('+'):
                args = res_array[index].split(" ")
                cmd_dict[index] = {}
                cmd_dict[index]['cmd'] = ' '.join(args[1:])
                cmd_dict[index]['serial_num'] = index
                cmd_dict[index]['plus_num'] = ''.join(args[0:1]).count('+')

        while None in cmd_dict:
            cmd_dict.remove(None)
        print(cmd_dict)
        return cmd_dict

    def _get_plus_cmd(self, array, plus_num):
        res = []
        for a in array:
            if a['plus_num'] == plus_num:
                res.append(a)
            else:
                pass
        return res

    def _get_max_serial_cmd(self, array):
        max_cmd = ''
        max_serial_num = 0
        for sc in array:
            if sc['serial_num'] > max_serial_num:
                max_serial_num = sc['serial_num']
                max_cmd = sc['cmd']
            else:
                pass
        return max_cmd

    def analyze(self):
        oneplus_count = 0
        otherplus_count = 0
        iterative_flag = False
        binbash_flag = False
        reg = re.compile(r'(eval|printf|echo)\s+\'.*([\$\'\"~\{\}\[\]#\*\`]+.*)\'$')
        if len(self._bash_debug()) == 0:
            self.res['message'] = 'Error: illegal bash script'
        else:
            for c in self._bash_debug():
                if c['plus_num'] == 1:
                    oneplus_count = oneplus_count + 1
                    if reg.match(c['cmd']) != None:
                        iterative_flag = True
                    else:
                        pass
                    if (c['cmd']).strip() in ['bash', '/usr/bin/sh', '/bin/bash', '/bin/sh', '/usr/bin/bash']:
                        binbash_flag = True
                    else:
                        pass
                else:
                    otherplus_count = otherplus_count + 1
            if oneplus_count == 1:
                if iterative_flag == False:
                    if binbash_flag == False:
                        self.res['original_cmd'] = []
                        self.res['original_cmd'].append(self._get_plus_cmd(self._bash_debug(), 1)[0]['cmd'])
                        self.res['obfus_func'] = []
                        self.res['obfus_func'] = self._func_hit(self._bash_debug())
                        ocmd_hash = simhash(self.cmd).hash
                        rcmd_hash = simhash(self._get_plus_cmd(self._bash_debug(), 1)[0]['cmd']).hash
                        haiming_dis = simhash.haiming_distance(ocmd_hash, rcmd_hash)
                        self.res['haiming_dis'] = haiming_dis
                        if len(self.res['obfus_func']) > 0:
                            if haiming_dis < 6:
                                self.res['is_obfus'] = False
                            else:
                                self.res['is_obfus'] = True
                        else:
                            if haiming_dis < 6:
                                self.res['is_obfus'] = False
                            else:
                                self.res['is_obfus'] = True
                    else:
                        twoplus_cmds = self._get_plus_cmd(self._bash_debug(), 2)
                        max_serial_cmd = self._get_max_serial_cmd(twoplus_cmds)
                        temp_func_hit = self._func_hit(twoplus_cmds)
                        if len(temp_func_hit) > 0:
                            self.res['original_cmd'] = []
                            for tc in twoplus_cmds:
                                self.res['original_cmd'].append(tc['cmd'])
                        else:
                            max_serial_cmd = self._get_max_serial_cmd(twoplus_cmds)
                        self.res['obfus_func'] = []
                        self.res['obfus_func'] = self._func_hit(self._bash_debug())
                        ocmd_hash = simhash(self.cmd).hash
                        rcmd_hash = simhash(max_serial_cmd).hash
                        haiming_dis = simhash.haiming_distance(ocmd_hash, rcmd_hash)
                        self.res['haiming_dis'] = haiming_dis
                        if len(self.res['obfus_func']) > 0:
                            if haiming_dis < 6:
                                self.res['is_obfus'] = False
                            else:
                                self.res['is_obfus'] = True
                        else:
                            if haiming_dis < 6:
                                self.res['is_obfus'] = False
                            else:
                                self.res['is_obfus'] = True
                else:
                    twoplus_cmds = self._get_plus_cmd(self._bash_debug(), 2)
                    temp_func_hit = self._func_hit(twoplus_cmds)
                    print(temp_func_hit)
                    if len(temp_func_hit) > 0:
                        self.res['original_cmd'] = []
                        for tc in twoplus_cmds:
                            self.res['original_cmd'].append(tc['cmd'])
                    else:
                        max_serial_cmd = self._get_max_serial_cmd(twoplus_cmds)
                        self.res['original_cmd'] = []
                        self.res['original_cmd'].append(max_serial_cmd)
                    self.res['obfus_func'] = []
                    self.res['obfus_func'] = self._func_hit(self._bash_debug())
                    self.res['is_obfus'] = True

            elif oneplus_count > 1:
                if iterative_flag == False:
                    cmd_str = ''
                    self.res['original_cmd'] = []
                    for pc in self._get_plus_cmd(self._bash_debug(), 1):
                        cmd_str = cmd_str + pc['cmd']
                        self.res['original_cmd'].append(pc['cmd'])
                        self.res['obfus_func'] = []
                        self.res['obfus_func'] = self._func_hit(self._bash_debug())
                        ocmd_hash = simhash(self.cmd).hash
                        rcmd_hash = simhash(cmd_str).hash
                        haiming_dis = simhash.haiming_distance(ocmd_hash, rcmd_hash)
                        self.res['haiming_dis'] = haiming_dis
                        if len(self.res['obfus_func']) > 0:
                            if haiming_dis < 6:
                                self.res['is_obfus'] = False
                            else:
                                self.res['is_obfus'] = True
                        else:
                            if haiming_dis < 6:
                                self.res['is_obfus'] = False
                            else:
                                self.res['is_obfus'] = True
